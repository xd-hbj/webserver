#ifndef THREADPOOL_H
#define THREADPOOL_H

#include<queue>
#include<pthread.h>
#include"lock.h"
#include"http_conn.h"
using namespace std;

extern void deleteAndsetnull(void *ptr);

template<typename T>
class threadpool{
    public:
        threadpool(int thread_numer=10,int max_request=1000);
        ~threadpool(){
            deleteAndsetnull(m_threads);
        }
        bool append(T* request);
        void run();
        void* worker(void* arg);

    private:
        int m_thread_number;
        int m_max_request;
        T* m_threads;
        queue<T*> m_workqueue;
        locker m_queuelocker;
        sem m_queuesem;
        cond m_cond;
        bool m_stop;//if stop thread?
};


#endif